''''''        '''KNN 手写数字识别'''


import os,time,operator             #导入os内置库读取文件名     导入time测试效率
import pandas as pd                 #导入数据处理库pandas       
import numpy as np                  #导入科学计算库numpy         
import matplotlib.pyplot as plt     #导入绘图库matplotlib      

trainingDigits =r'D:\KNN\trainingDigits'
testDigits = r'D:\KNN\testDigits'
                                                         
tarining = (os.listdir(trainingDigits))                 ## 读取训练集
test = (os.listdir(testDigits))                        ## 读取测试集
def read_file(doc_name):                             ## 定义一个把32x32格式转为1行的函数
    data=np.zeros((1,1024))                         ## 创建1个zero数组
    f=open(doc_name)                              
    for i in range(32):                          
        hang=f.readline()                       ## 取行
        for j in range(32):                   ## 取每行中的每一列
            data[0,32*i+j]=int(hang[j])      ## 给data值
    # print(pd.DataFrame(data))            
    return data                           
                                        

def dict_list(dic:dict):               ## 定义函数将字典转化为列表
    keys = dic.keys()                
    values = dic.values()           
    lst = [(key,val) for  key,val in zip(keys, values)] 
    return lst                        ## zip是一个可迭代对象
                                        ## 返回一个列表

def xiangsidu(tests,xunlians,labels,k):    ## tests:测试集 # xulians:训练样本集 # labels:标签 # k: 邻近的个数
    data_hang=xunlians.shape[0]              ## 获取训练集的行数data_hang
    zu=np.tile(tests,(data_hang,1))-xunlians   ## 用tile把测试集tests重构成一个 data_hang行、1列的1维数组
    q=np.sqrt((zu**2).sum(axis=1)).argsort()     ## 计算完距离后从低到高排序,argsort返回的是索引
    my_dict = {}                                   ## 设置一个dict
    for i in range(k):                              
        votelabel=labels[q[i]]                         ## q[i]是索引值,通过labels来获取对应标签
        my_dict[votelabel] = my_dict.get(votelabel,0)+1   ## 统计每个标签的次数
    sortclasscount=sorted(dict_list(my_dict),key=operator.itemgetter(1),reverse=True)
                                                         ## 获取votelabel键对应的值，无返回默认
    return sortclasscount[0][0]                        ## 返回出现频次最高的类别


def shibie():                                        ## 定义一个识别手写数字的函数
    label_list = []                                    ## 将训练集存储到一个矩阵并存储标签
    train_length = len(tarining)                        
    train_zero = np.zeros((train_length,1024))           ## 创建(训练集长度，1024)维度的zeros数组
    for i in range(train_length):                         ## 通过遍历训练集长度
        doc_name = tarining[i]                              ## 获取所有的文件名
        file_label = int(doc_name[0])                         ## 取文件名第一位文件的标签
        label_list.append(file_label)                           ## 将标签添加至handlabel中
        train_zero[i,:] = read_file(r'%s\%s'%(trainingDigits,doc_name))## 转成1024的数组
                                                                  
    errornum = 0                                                  ## 记录error的初值
    testnum = len(test)                                         
    errfile = []                                              ## 定义一个空列表
    for i in range(testnum):                               ## 将每一个测试样本放入训练集中使用KNN进行测试
        testdoc_name = test[i]                           ## 通过i当作下标来获取测试集里面的文件
        test_label = int(testdoc_name[0])              ## 拿到测试文件的名字 拿到我们的数字标签
        testdataor = read_file(r'%s\%s' %(testDigits,testdoc_name)) 
        result = xiangsidu(testdataor, train_zero, label_list, 3)  
        print("正在测试 %d, 内容是 %d" % (test_label,result))   
        if (result != test_label):                               ## 判断标签是否等于测试名
            errornum += 1                                       
            errfile.append(testdoc_name)                       ## 把错误的文件名加入错误列表
    print("错误数量有 :%d" % errornum)                       
    print("错误的有 :%s"%[i for i in errfile])             #
    print("准确率 %.2f%%" % ((1 - (errornum / float(testnum))) * 100)) ## 计算准确率

if __name__ == '__main__':                                       
    a = time.time()                                              ## 设置起始时间
    shibie()                                                 
    b= time.time() - a                                       ## 计算运行时间
    print("运行时间:",b)                                   

